import sys

def types(x):
        print("My book is: ",x)
