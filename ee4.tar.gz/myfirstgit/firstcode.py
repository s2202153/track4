import sys
import time
import lib_book as lb

print("Good day & hello s2202153")
lb.types("Electrical")

